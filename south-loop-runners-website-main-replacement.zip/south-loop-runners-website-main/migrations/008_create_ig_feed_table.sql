-- Instagram feed table for homepage display
CREATE TABLE IF NOT EXISTS ig_feed (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  URL TEXT NOT NULL,
  caption TEXT,
  display_order INTEGER DEFAULT 0,
  is_active INTEGER DEFAULT 1,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_ig_feed_active ON ig_feed(is_active, display_order);
